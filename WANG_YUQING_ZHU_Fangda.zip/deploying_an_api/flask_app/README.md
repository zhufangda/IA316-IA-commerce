## Flask API

### Warning
You should not run Flask without a web server on top of it. 
This code is for demo only. 
Look on Flask documentation to see why Flask’s built-in server is not suitable for production


### Requirement
You need install docker to run this code.

```bash
bash rebuild_docker.sh
```