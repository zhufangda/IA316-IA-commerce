## Deploying an API with Flask, Nginx and docker-compose

First you need to install docker and docker-compose.

You can then run the API

```bash
docker-compose up --build
```


